//
//  StoreManager.h
//  SampleServerDemo
//
//  Created by Vishnu on 21/08/14.
//  Copyright (c) 2014 Vishnu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface StoreManager : NSObject

    -( DataHandler *) getStore;

@end
