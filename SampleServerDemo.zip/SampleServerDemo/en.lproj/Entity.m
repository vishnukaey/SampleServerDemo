//
//  Entity.m
//  SampleServerDemo
//
//  Created by Vishnu on 26/08/14.
//  Copyright (c) 2014 Vishnu. All rights reserved.
//

#import "Entity.h"


@implementation Entity

@dynamic code;
@dynamic colour;
@dynamic flag;
@dynamic item;

@end
