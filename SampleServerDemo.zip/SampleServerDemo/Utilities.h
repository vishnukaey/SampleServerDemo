//
//  SeatingLayoutViewController.m
//  Please Sit
//
//  Created by Vishnu on 01/07/14.
//  Copyright (c) 2014 Qburst. All rights reserved.


#import <Foundation/Foundation.h>

@interface Utilities : NSObject

+ (void) showAlert:(NSString *)message withTitle:(NSString *)title;

@end
